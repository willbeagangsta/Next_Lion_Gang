var hw = document.getElementById("hw");
hw.addEventListener("click", () => alert("hi"));
